from django.contrib import admin
from .models import Donor # Import all your models

# Register the models so they show up in the admin panel
admin.site.register(Donor)
