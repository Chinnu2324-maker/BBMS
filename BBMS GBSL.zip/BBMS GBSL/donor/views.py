from django.shortcuts import render, redirect, reverse, get_object_or_404
from . import forms, models
from django.db.models import Sum, Q
from django.contrib.auth.models import Group
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.conf import settings
from datetime import date, timedelta
from django.core.mail import send_mail
from django.contrib.auth.models import User
from blood import forms as bforms
from blood import models as bmodels
from donor import models as dmodels


# Single is_admin_or_patient function only
def is_admin_or_patient(user):
    return user.is_staff or hasattr(user, 'patient')

@login_required
@user_passes_test(is_admin_or_patient)
def view_donor_location(request, donor_id):
    donor = get_object_or_404(models.Donor, id=donor_id)
    return render(request, 'donor/donor_location.html', {'donor': donor})

def donor_signup_view(request):
    userForm = forms.DonorUserForm()
    donorForm = forms.DonorForm()
    mydict = {'userForm': userForm, 'donorForm': donorForm}
    if request.method == 'POST':
        userForm = forms.DonorUserForm(request.POST)
        donorForm = forms.DonorForm(request.POST, request.FILES)
        if userForm.is_valid() and donorForm.is_valid():
            user = userForm.save()
            user.set_password(user.password)
            user.save()
            donor = donorForm.save(commit=False)
            donor.user = user
            donor.bloodgroup = donorForm.cleaned_data['bloodgroup']
            donor.save()
            my_donor_group, created = Group.objects.get_or_create(name='DONOR')
            my_donor_group.user_set.add(user)
            return HttpResponseRedirect('donorlogin')
    return render(request, 'donor/donorsignup.html', context=mydict)

def donor_dashboard_view(request):
    donor = get_object_or_404(models.Donor, user_id=request.user.id)
    dict = {
        'requestpending': bmodels.BloodRequest.objects.filter(request_by_donor=donor, status='Pending').count(),
        'requestapproved': bmodels.BloodRequest.objects.filter(request_by_donor=donor, status='Approved').count(),
        'requestmade': bmodels.BloodRequest.objects.filter(request_by_donor=donor).count(),
        'requestrejected': bmodels.BloodRequest.objects.filter(request_by_donor=donor, status='Rejected').count(),
    }
    return render(request, 'donor/donor_dashboard.html', context=dict)

def donate_blood_view(request):
    donation_form = forms.DonationForm()
    if request.method == 'POST':
        donation_form = forms.DonationForm(request.POST)
        if donation_form.is_valid():
            blood_donate = donation_form.save(commit=False)
            blood_donate.bloodgroup = donation_form.cleaned_data['bloodgroup']
            donor = get_object_or_404(models.Donor, user_id=request.user.id)
            blood_donate.donor = donor
            blood_donate.save()
            return HttpResponseRedirect('donation-history')
    return render(request, 'donor/donate_blood.html', {'donation_form': donation_form})

def donation_history_view(request):
    donor = get_object_or_404(models.Donor, user_id=request.user.id)
    donations = models.BloodDonate.objects.filter(donor=donor)
    return render(request, 'donor/donation_history.html', {'donations': donations})

def make_request_view(request):
    request_form = bforms.RequestForm()
    if request.method == 'POST':
        request_form = bforms.RequestForm(request.POST)
        if request_form.is_valid():
            blood_request = request_form.save(commit=False)
            blood_request.bloodgroup = request_form.cleaned_data['bloodgroup']
            donor = get_object_or_404(models.Donor, user_id=request.user.id)
            blood_request.request_by_donor = donor
            blood_request.save()
            return HttpResponseRedirect('request-history')
    return render(request, 'donor/makerequest.html', {'request_form': request_form})


def request_history_view(request):
    donor = get_object_or_404(models.Donor, user_id=request.user.id)
    blood_request = bmodels.BloodRequest.objects.filter(request_by_donor=donor)
    return render(request, 'donor/request_history.html', {'blood_request': blood_request})

def send_blood_request_email(bloodgroup):
    donors = dmodels.Donor.objects.filter(bloodgroup=bloodgroup)
    subject = 'Urgent Blood Requirement'
    message = f'Dear Donor,\n\nWe need blood group {bloodgroup} urgently. Please donate if you can.\n\nThank you!'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [donor.user.email for donor in donors if donor.user.email]

    if recipient_list:
        send_mail(subject, message, email_from, recipient_list)

